# -*- coding: utf-8 -*-

print(int(1000/23))
