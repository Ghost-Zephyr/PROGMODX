# -*- coding: utf-8 -*-

print('Programmering er veldig "kult"!')
