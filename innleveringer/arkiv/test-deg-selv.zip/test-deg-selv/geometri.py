# -*- coding: utf-8 -*-

import numpy as np

r = 5.4
h = 7.9

O = 2 * np.math.pi * 5.4
As = np.math.pi * 5.4**2
Ay = O * 7.9 + 2 * As

print("Har en sirkel med radius", r, "som er grunnflate i en sylinder med høyde", h)
print("Omkrets av sirkelen:", O)
print("Areal av sirkelen:", As)
print("Areal av sylinderen:", Ay)
