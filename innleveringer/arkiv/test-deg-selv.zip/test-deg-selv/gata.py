# -*- coding: utf-8 -*-

gate = 'Kongens gate'
husnr = 432
oppgang = "b"

adresse = "{} {}{}".format(gate, str(husnr), oppgang)

print(adresse)
