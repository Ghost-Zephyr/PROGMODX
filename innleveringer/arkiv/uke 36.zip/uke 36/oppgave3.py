# -*- coding: utf-8 -*-

fornavn = str(input("Fornavn: "))
etternavn = str(input("Etternavn: "))

print("\n\nHallo, {} {}.\nTakk for at du kjører min kode!".format(fornavn, etternavn))

