# -*- coding: utf-8 -*-

m = 1.2
g = 9.81
h = 4.91

F = m * g * h

print("En ball på {}kg {}m over bakken har en potensiell energi på {}N".format(m, h, F))

