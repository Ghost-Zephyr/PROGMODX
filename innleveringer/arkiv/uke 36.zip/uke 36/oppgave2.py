# -*- coding: utf-8 -*-

navn = "Sivert V. Sæther"
adresse = "Romolslia 33c"
tlf = "98465910"

print("\nNavn: {}\nAdresse: {}\nTelefon: {}\n\nOg disse lagres ved type: {}".format(
        navn, adresse, tlf, type("")))
