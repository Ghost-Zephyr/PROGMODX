# -*- coding: utf-8 -*-
# næ ass

print("Hallo Norge!")

