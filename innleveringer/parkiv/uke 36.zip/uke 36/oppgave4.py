# -*- coding: utf-8 -*-

m = 1.2
g = 9.81
h = 4.91

F = m * g * h

print(f"En ball på {m}kg {h}m over bakken har en potensiell energi på {round(F,3)}N")

