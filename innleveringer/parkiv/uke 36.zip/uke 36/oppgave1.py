# -*- coding: utf-8 -*-

# bruh
print("Hallo Norge!")

