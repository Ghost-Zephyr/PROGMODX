# -*- coding: utf-8 -*-

fornavn = str(input("Fornavn: "))
etternavn = str(input("Etternavn: "))

print(f"\n\nHallo, {fornavn} {etternavn}.\nTakk for at du kjører min kode!")

